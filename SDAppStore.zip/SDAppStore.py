import os
import sys
import requests
import subprocess
import shutil
import zipfile
from io import BytesIO
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QLineEdit, QHBoxLayout
)
from PyQt5.QtGui import QPixmap
import easygui
import platform
from tqdm import tqdm

# API Endpoint
API_URL = "https://alexidians.com/SD-App-Store/Apps/config.php"

# App Installation Path
INSTALL_PATH = "Apps"
INSTALLER_TMP_PATH = "tmp/installer"
os.makedirs(INSTALL_PATH, exist_ok=True)
os.makedirs(INSTALLER_TMP_PATH, exist_ok=True)

def download_file(url, save_path):
    """Download a file from a URL and save it."""
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(save_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        print(f"Downloaded: {save_path}")
        return True
    except Exception as e:
        print(f"Download failed: {e}")
        return False

def extract_zip(zip_file_path, output_dir):
    # Check if the ZIP file exists
    if not os.path.exists(zip_file_path):
        print(f"Error: The file {zip_file_path} does not exist.")
        return
    
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Open the ZIP file and initialize tqdm for progress
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        # Initialize tqdm progress bar for the files being extracted
        total_files = len(zip_ref.infolist())
        with tqdm(total=total_files, desc="Extracting", unit="file") as pbar:
            for file in zip_ref.namelist():
                # Check if file exists and remove it to allow overwriting
                file_path = os.path.join(output_dir, file)
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                zip_ref.extract(file, output_dir)
                pbar.update(1)
            print(f"Extracted all files to {output_dir}")


def get_platform():
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "linux":
        return "linux"
    elif system == "darwin":
        return "darwin"
    else:
        return "Unknown"

def install_app(uuid, meta_url):
    print(f"Installing app {uuid} from {meta_url}...")
    os.makedirs(f"{INSTALL_PATH}/{uuid}", exist_ok=True)
    with open(f"{INSTALL_PATH}/{uuid}/meta_url.txt", "w") as meta_urlf:
        meta_urlf.write(meta_url)
    os.makedirs(f"{INSTALLER_TMP_PATH}/{uuid}", exist_ok=True)
    download_file(meta_url, f"{INSTALLER_TMP_PATH}/{uuid}/meta.zip")
    extract_zip(f"{INSTALLER_TMP_PATH}/{uuid}/meta.zip", f"{INSTALL_PATH}/{uuid}")
    warncustomsetupgui = False
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/warncustomsetupgui.txt"):
        with open(f"{INSTALL_PATH}/{uuid}/warncustomsetupgui.txt", "r") as warncustomsetupguif:
            warncustomsetupgui = warncustomsetupguif.read().strip().lower() == "true"
    if warncustomsetupgui:
        if easygui.ynbox("This app uses a custom setup gui. Do you want to continue?", "Custom Setup GUI Is Used"):
            print("Continuing...")
        else:
            print("Cancelling...")
            return
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/install.py"):
        subprocess.Popen([sys.executable, "install.py"], cwd=f"{INSTALL_PATH}/{uuid}")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/installer.msi"):
     if get_platform() == "windows":
        installermsitype = ["auto", "gui/progress"]
        if os.path.exists(f"{INSTALL_PATH}/{uuid}/installer.msi.type.txt"):
            with open(f"{INSTALL_PATH}/{uuid}/installer.msi.type.txt", "r") as installertypemsif:
                installermsitype = installertypemsif.read().strip().lower().split(",")
        guiopts = "/"
        if installermsitype.count("auto") > 0:
            guiopts += "q"
        if installermsitype.count("gui/progress") > 0:
            guiopts += "b"
        if installermsitype.count("gui/none") > 0:
            guiopts += "n"
        if guiopts == "/":
            guiopts = ""
        # msiexec /i "C:\path\to\installer.msi" TARGETDIR="C:\Your\Install\Path" /qn
        # Running the msiexec command using subprocess.Popen
        subprocess.Popen([
            "msiexec", 
            "/i", 
            os.path.abspath(f"{INSTALL_PATH}/{uuid}/installer.msi"), 
            f"TARGETDIR={os.path.abspath(f"{INSTALL_PATH}/{uuid}/msi.install")}", 
            guiopts,
            "/norestart"
        ], cwd=f"{INSTALL_PATH}/{uuid}")
     else:
        print("This app is only available for Windows. due to the installer being an MSI file. Please try again on a Windows machine. or the install.py file will install it.")

def uninstall_app(uuid):
    print(f"Uninstalling app {uuid}...")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/uninstall.py"):
        subprocess.Popen([sys.executable, "uninstall.py"], cwd=f"{INSTALL_PATH}/{uuid}")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/installer.msi"):
        if get_platform() == "windows":
            subprocess.Popen([
                "msiexec", 
                "/x", 
                os.path.abspath(f"{INSTALL_PATH}/{uuid}/installer.msi"), 
                "/qb",
                "/norestart"
            ], cwd=f"{INSTALL_PATH}/{uuid}")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}"):
        shutil.rmtree(f"{INSTALL_PATH}/{uuid}")

def update_app(uuid):
    print(f"Updating app {uuid}...")
    meta_url = None
    with open(f"{INSTALL_PATH}/{uuid}/meta_url.txt", "r") as meta_urlf:
        meta_url = meta_urlf.read().strip()
    os.makedirs(f"{INSTALLER_TMP_PATH}/{uuid}", exist_ok=True)
    download_file(meta_url, f"{INSTALLER_TMP_PATH}/{uuid}/meta.zip")
    extract_zip(f"{INSTALLER_TMP_PATH}/{uuid}/meta.zip", f"{INSTALL_PATH}/{uuid}")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/update.py"):
        subprocess.Popen([sys.executable, "update.py"], cwd=f"{INSTALL_PATH}/{uuid}")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/installer.msi"):
        if get_platform() == "windows":
            subprocess.Popen([
                "msiexec", 
                "/i", 
                os.path.abspath(f"{INSTALL_PATH}/{uuid}/installer.msi"), 
                "/qb",
                "/norestart"
            ], cwd=f"{INSTALL_PATH}/{uuid}")

def launch_app(uuid):
    print(f"Launching app {uuid}...")
    if os.path.exists(f"{INSTALL_PATH}/{uuid}/launch.py"):
        subprocess.Popen([sys.executable, "launch.py"], cwd=f"{INSTALL_PATH}/{uuid}")

def load_installed_apps():
    """Load all installed apps by reading name.txt."""
    installed_apps = []
    for uuid in os.listdir(INSTALL_PATH):
        app_path = os.path.join(INSTALL_PATH, uuid)
        if os.path.isdir(app_path) and os.path.exists(os.path.join(app_path, "name.txt")):
            with open(os.path.join(app_path, "name.txt"), "r") as name_file:
                app_name = name_file.read().strip()
                installed_apps.append({"uuid": uuid, "name": app_name})
    return installed_apps

class AppStore(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SD App Store")
        self.setGeometry(100, 100, 600, 500)

        self.apps = []  # Store loaded apps
        self.installed_apps = []  # Store installed apps
        self.init_ui()
        self.load_apps()
        self.load_installed_apps()

    def init_ui(self):
        layout = QVBoxLayout()

        # Search Bar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search apps...")
        self.search_input.textChanged.connect(self.filter_apps)
        layout.addWidget(self.search_input)

        # App List
        self.app_list = QListWidget()
        self.app_list.itemSelectionChanged.connect(self.update_buttons)
        layout.addWidget(self.app_list)

        # Installed Apps Search Bar
        self.installed_search_input = QLineEdit()
        self.installed_search_input.setPlaceholderText("Search installed apps...")
        self.installed_search_input.textChanged.connect(self.filter_installed_apps)
        layout.addWidget(self.installed_search_input)

        # Buttons Layout
        button_layout = QHBoxLayout()
        
        self.install_button = QPushButton("Install")
        self.install_button.clicked.connect(self.install_selected)
        button_layout.addWidget(self.install_button)

        self.uninstall_button = QPushButton("Uninstall")
        self.uninstall_button.clicked.connect(self.uninstall_selected)
        button_layout.addWidget(self.uninstall_button)

        self.update_button = QPushButton("Update")
        self.update_button.clicked.connect(self.update_selected)
        button_layout.addWidget(self.update_button)

        self.launch_button = QPushButton("Launch")
        self.launch_button.clicked.connect(self.launch_selected)
        button_layout.addWidget(self.launch_button)

        layout.addLayout(button_layout)

        # Container
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        self.update_buttons()

    def load_apps(self):
        """Fetch apps from the API."""
        try:
            response = requests.get(API_URL, params={"q": ""})
            response.raise_for_status()
            self.apps = response.json()
            self.filter_apps()
        except Exception as e:
            print("Failed to load apps:", e)

    def load_installed_apps(self):
        """Fetch installed apps."""
        self.installed_apps = load_installed_apps()
        self.filter_installed_apps()

    def filter_apps(self):
        """Filter the app list based on the search bar input."""
        search_text = self.search_input.text().lower()
        self.app_list.clear()

        for app in self.apps:
            if search_text in app["name"].lower():
                item = QListWidgetItem(app["name"])  # Display name
                item.setData(100, app)  # Store full app data
                self.app_list.addItem(item)

    def filter_installed_apps(self):
        """Filter the installed apps list based on the installed apps search input."""
        search_text = self.installed_search_input.text().lower()
        self.app_list.clear()

        for app in self.installed_apps:
            if search_text in app["name"].lower():
                item = QListWidgetItem(app["name"])  # Display name
                appdata = app.copy()
                appdata["meta_url"] = "This is broken"
                if os.path.exists(appdata["uuid"] + "/meta_url.txt"):
                 with open(appdata["uuid"] + "/meta_url.txt", "r") as meta_urlf:
                    appdata["meta_url"] = meta_urlf.read()
                item.setData(100, appdata)  # Store full app data
                self.app_list.addItem(item)

    def update_buttons(self):
        """Enable/disable buttons based on whether the app is installed."""
        selected_item = self.app_list.currentItem()
        if not selected_item:
            self.install_button.setEnabled(False)
            self.uninstall_button.setEnabled(False)
            self.update_button.setEnabled(False)
            self.launch_button.setEnabled(False)
            return

        app = selected_item.data(100)
        app_path = os.path.join(INSTALL_PATH, app["uuid"])

        if os.path.exists(app_path):
            self.install_button.setEnabled(False)  # Already installed
            self.uninstall_button.setEnabled(True)
            self.update_button.setEnabled(True)
            self.launch_button.setEnabled(True)
        else:
            self.install_button.setEnabled(True)
            self.uninstall_button.setEnabled(False)
            self.update_button.setEnabled(False)
            self.launch_button.setEnabled(False)

    def install_selected(self):
        """Install the selected app using UUID."""
        selected_item = self.app_list.currentItem()
        if selected_item:
            app = selected_item.data(100)
            install_app(app["uuid"], app["meta_url"])
            self.update_buttons()

    def launch_selected(self):
        """Install the selected app using UUID."""
        selected_item = self.app_list.currentItem()
        if selected_item:
            app = selected_item.data(100)
            launch_app(app["uuid"])
            self.update_buttons()

    def uninstall_selected(self):
        """Uninstall the selected app using UUID."""
        selected_item = self.app_list.currentItem()
        if selected_item:
            app = selected_item.data(100)
            uninstall_app(app["uuid"])
            self.update_buttons()

    def update_selected(self):
        """Update the selected app using UUID."""
        selected_item = self.app_list.currentItem()
        if selected_item:
            app = selected_item.data(100)
            update_app(app["uuid"])

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AppStore()
    window.show()
    sys.exit(app.exec_())
