import os
import subprocess
import platform
import requests
import urllib3
import easygui

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def download_roblox_installer(url, save_path):
    # Download the Roblox installer while ignoring SSL verification
    response = requests.get(url, verify=False)  # Disables SSL verification
    if response.status_code == 200:
        with open(save_path, 'wb') as file:
            file.write(response.content)
        return save_path
    else:
        print("Failed to download Roblox installer.")
        return None

def install_roblox():
    os_type = platform.system().lower()

    # Define the current directory to save the installer
    current_dir = os.getcwd()

    if os_type == "windows":
        # URL for Roblox installer on Windows
        roblox_installer_url = "https://setup.rbxcdn.com/RobloxPlayerLauncher.exe"
        
        installer_path = os.path.join(current_dir, "RobloxPlayerLauncher.exe")
        installer_path = download_roblox_installer(roblox_installer_url, installer_path)
        
        if installer_path:
            print(f"Downloaded Roblox installer to {installer_path}")
            # Run the installer
            try:
                subprocess.run([installer_path], check=True)
            except subprocess.CalledProcessError:
                easygui.msgbox("Roblox installation failed.")
            os.remove(installer_path)  # Clean up the installer after running
            print("Roblox installation complete!")

    elif os_type == "darwin":  # macOS
        # URL for Roblox installer on macOS
        roblox_installer_url = "https://setup.rbxcdn.com/Roblox.dmg"
        
        installer_path = os.path.join(current_dir, "Roblox.dmg")
        installer_path = download_roblox_installer(roblox_installer_url, installer_path)
        
        if installer_path:
            print(f"Downloaded Roblox installer to {installer_path}")
            # Mount the .dmg file
            subprocess.run(["hdiutil", "attach", installer_path], check=True)
            os.remove(installer_path)  # Clean up the installer after mounting
            print("Roblox installer mounted. You can now drag the app into your Applications folder.")
        else:
            print("Roblox installation failed.")

    else:
        print(f"Unsupported operating system: {os_type}")

# Run the installation function
install_roblox()
