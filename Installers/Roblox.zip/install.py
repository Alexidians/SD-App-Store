import os
import subprocess
import platform
import requests
import easygui

def download_roblox_installer(url, save_path):
    # Download the Roblox installer to the specified location
    response = requests.get(url)
    if response.status_code == 200:
        with open(save_path, 'wb') as file:
            file.write(response.content)
        return save_path
    else:
        easygui.msgbox("Failed to download Roblox installer.")
        return None

def install_roblox():
    os_type = platform.system().lower()

    # Define the current directory to save the installer
    current_dir = os.getcwd()

    if os_type == "windows":
        # URL for Roblox installer on Windows
        roblox_installer_url = "https://setup.roblox.com/RobloxPlayerLauncher.exe"
        
        installer_path = os.path.join(current_dir, "RobloxPlayerLauncher.exe")
        installer_path = download_roblox_installer(roblox_installer_url, installer_path)
        
        if installer_path:
            print(f"Downloaded Roblox installer to {installer_path}")
            # Run the installer
            subprocess.run([installer_path], check=True)
            os.remove(installer_path)  # Clean up the installer after running
            print("Roblox installation complete!")

    elif os_type == "darwin":  # macOS
        # URL for Roblox installer on macOS
        roblox_installer_url = "https://setup.roblox.com/Roblox.dmg"
        
        installer_path = os.path.join(current_dir, "Roblox.dmg")
        installer_path = download_roblox_installer(roblox_installer_url, installer_path)
        
        if installer_path:
            print(f"Downloaded Roblox installer to {installer_path}")
            # Mount the .dmg file
            subprocess.run(["hdiutil", "attach", installer_path], check=True)
            os.remove(installer_path)  # Clean up the installer after mounting
            easygui.msgbox("Roblox installer mounted. You can now drag the app into your Applications folder.")
        else:
            easygui.msgbox("Roblox installation failed.")

    else:
        easygui.msgbox(f"Unsupported operating system: {os_type}")

# Run the installation function
install_roblox()
