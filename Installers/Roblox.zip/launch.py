import subprocess
import os
import platform

def launch_roblox():
    os_type = platform.system().lower()

    if os_type == "windows":
        # Use environment variables to locate Roblox on Windows
        roblox_path = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Roblox", "Versions")
        roblox_exe = next((f for f in os.listdir(roblox_path) if f.startswith("version-")), None)

        if roblox_exe:
            roblox_launcher = os.path.join(roblox_path, roblox_exe, "RobloxPlayerBeta.exe")
            if os.path.exists(roblox_launcher):
                subprocess.Popen(roblox_launcher)
            else:
                print("Roblox launcher not found!")
        else:
            print("Roblox version folder not found!")

    elif os_type == "linux":
        # For Linux, using Wine, the path is usually ~/.wine/drive_c/Program Files/Roblox/
        roblox_path = os.path.expanduser("~/.wine/drive_c/Program Files/Roblox/Versions")
        roblox_exe = next((f for f in os.listdir(roblox_path) if f.startswith("version-")), None)

        if roblox_exe:
            roblox_launcher = os.path.join(roblox_path, roblox_exe, "RobloxPlayerBeta.exe")
            if os.path.exists(roblox_launcher):
                subprocess.Popen(['wine', roblox_launcher])
            else:
                print("Roblox launcher not found!")
        else:
            print("Roblox version folder not found!")

    elif os_type == "darwin":  # macOS
        roblox_path = "/Applications/Roblox.app"
        if os.path.exists(roblox_path):
            subprocess.Popen(["open", roblox_path])
        else:
            print("Roblox app not found on macOS!")

    else:
        print(f"Unsupported operating system: {os_type}")

# Run the function to launch Roblox automatically
launch_roblox()
