
import os
import subprocess
import sys

# Function to install required modules
def install_requirements():
    try:
        # Try importing selenium and selenium_stealth
        import selenium
        import selenium_stealth
    except ImportError:
        # Install selenium and selenium_stealth if they are not already installed
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "selenium", "selenium-stealth"])
        except subprocess.CalledProcessError:
            print("Error installing required modules. Please check your environment.")
            sys.exit(1)

# Create data directory if it doesn't exist
def create_data_directory():
    if not os.path.exists('data'):
        os.makedirs('data')

# Set up and open the Chrome browser with Selenium and Stealth
def open_chrome_browser():
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from webdriver_manager.chrome import ChromeDriverManager
    from selenium_stealth import stealth

    # Set up Chrome options
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--user-data-dir=data")  # Save user data in data/ directory
    
    # Initialize the Chrome driver
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    
    # Apply stealth mode to the driver
    stealth(driver)

    # Do nothing, just leave the browser open

# Main function
def main():
    install_requirements()  # Ensure the required modules are installed
    create_data_directory()  # Ensure the data directory exists
    open_chrome_browser()  # Open the Chrome browser with stealth and save data

if __name__ == "__main__":
    main()
