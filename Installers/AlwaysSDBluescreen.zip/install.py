import os
import sys
import winshell
from win32com.client import Dispatch

def create_shortcut():
    # Get the absolute path of the batch file
    script_dir = os.path.abspath(os.path.dirname(__file__))
    batch_file = os.path.join(script_dir, "StartAlwaysBluescreen.bat")
    
    # Get the user's startup folder
    startup_folder = winshell.startup()
    shortcut_path = os.path.join(startup_folder, "StartAlwaysBluescreen.bat.lnk")
    
    # Create the shortcut
    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortcut(shortcut_path)
    shortcut.TargetPath = batch_file
    shortcut.WorkingDirectory = script_dir
    shortcut.Save()
    
    print(f"Shortcut created: {shortcut_path}")

if __name__ == "__main__":
    create_shortcut()
