import os
import zipfile
import requests
from tqdm import tqdm

def download_file(url, save_path):
    """Download a file from a URL and save it."""
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(save_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        print(f"Downloaded: {save_path}")
        return True
    except Exception as e:
        print(f"Download failed: {e}")
        return False

def extract_zip(zip_file_path, output_dir):
    # Check if the ZIP file exists
    if not os.path.exists(zip_file_path):
        print(f"Error: The file {zip_file_path} does not exist.")
        return
    
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Open the ZIP file and initialize tqdm for progress
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        # Initialize tqdm progress bar for the files being extracted
        total_files = len(zip_ref.infolist())
        with tqdm(total=total_files, desc="Extracting", unit="file") as pbar:
            for file in zip_ref.namelist():
                # Check if file exists and remove it to allow overwriting
                file_path = os.path.join(output_dir, file)
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                zip_ref.extract(file, output_dir)
                pbar.update(1)
            print(f"Extracted all files to {output_dir}")

def get_windows_category():
    release = platform.release()

    if release in {"Vista", "7"}:
        return "VistaN7"
    elif release in {"8", "8.1"}:
        return "8n8.1"
    elif release == "10":
        return "10"
    elif release == "11":
        return "11"
    else:
        return f"Unknown ({release})"

download_file("https://alexidians.github.io/SDBluescreen/" + get_windows_category() + "/SDBluescreen.zip", "SDBluescreen.zip")
extract_zip("SDBluescreen.zip", "SDBluescreen")