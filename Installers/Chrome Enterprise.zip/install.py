import requests
import easygui
import shutil
import os
import platform

def download_file(url, save_path):
    """Download a file from a URL and save it."""
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(save_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        print(f"Downloaded: {save_path}")
        return True
    except Exception as e:
        print(f"Download failed: {e}")
        return False

def get_platform():
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "linux":
        return "linux"
    elif system == "darwin":
        return "darwin"
    else:
        return "Unknown"

def cancel_download():
    easygui.msgbox("Download cancelled. Removing leftovers", "Download Cancelled")
    shutil.rmtree(os.path.dirname(__file__))

if get_platform() != "windows":
    easygui.msgbox("This application is only compatible with windows.", "Incompatible Platform")
    shutil.rmtree(os.path.dirname(__file__))

CHROME_MSI_DOWNLOAD_BASE_WIN = "https://chromeenterprise.google/download/thank-you/?platform=WIN{ARCHITECTURE}_MSI&channel={CHANNEL}&usagestats={USAGE_STATS}#"

architectured = easygui.choicebox("Select the architecture of your system.", "Architecture", ["32-bit", "64-bit", "ARM64"])
if architectured == "32-bit":
    architecture = "32"
elif architectured == "64-bit":
    architecture = "64"
elif architectured == "ARM64":
    architecture = "_ARM"
else:
    cancel_download()

channeld = easygui.choicebox("Select the channel of Chrome you want to download.", "Channel", ["stable", "beta"])
if channeld == "stable":
    channel = "stable"
elif channeld == "beta":
    channel = "beta"
else:
    cancel_download()

usage_statsd = easygui.choicebox("Do you want to enable usage statistics?", "Usage Statistics", ["Yes", "No"])
if usage_statsd == "Yes":
    usage_stats = "1"
elif usage_statsd == "No":
    usage_stats = "0"
else:
    cancel_download()

confirmtext = f"Download Chrome {channel} for Windows {architectured} with usage statistics {'enabled' if usage_statsd == 'Yes' else 'disabled'}?"
if easygui.ynbox(confirmtext, "Confirm Download"):
    download_file(CHROME_MSI_DOWNLOAD_BASE_WIN.format(ARCHITECTURE=architecture, CHANNEL=channel, USAGE_STATS=usage_stats), "installer.msi")
    easygui.msgbox("Download complete!", "Download Complete")
else:
    cancel_download()
