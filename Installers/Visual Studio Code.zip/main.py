from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Visual Studio Code")
        
        # Set up QWebEngineView to load the webpage
        self.browser = QWebEngineView(self)
        self.browser.setUrl(QUrl("https://vscode.dev"))  # Set your URL here
        self.setCentralWidget(self.browser)

        self.resize(1024, 768)  # Set window size

if __name__ == "__main__":
    app = QApplication([])
    window = Browser()
    window.show()
    app.exec_()
