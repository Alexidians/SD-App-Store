import subprocess
import sys

subprocess.Popen(["start", sys.executable, "SuperDiamondChrome.py"], cwd="SDChrome")