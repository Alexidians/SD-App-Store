import subprocess
import sys

subprocess.Popen([sys.executable, "SuperDiamondChrome.py"], cwd="SDChrome")