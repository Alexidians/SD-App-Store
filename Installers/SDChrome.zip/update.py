import subprocess
import sys

subprocess.Popen([sys.executable, "update.py"], cwd="SDChrome")