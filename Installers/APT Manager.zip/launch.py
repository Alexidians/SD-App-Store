import sys
import subprocess

# Check if the apt module is available
try:
    import apt
except ImportError:
    # Install the python3-apt package if not found
    print("apt module not found. Installing python3-apt...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python3-apt"])
    subprocess.check_call(["sudo", "apt", "install", "python3-apt"])
    import apt

import tkinter as tk
from tkinter import messagebox, ttk

# Initialize APT cache
cache = apt.Cache()

def install_package(package_name):
    try:
        pkg = cache[package_name]
        if pkg.is_installed:
            messagebox.showinfo("Info", f"{package_name} is already installed.")
        else:
            pkg.mark_install()
            cache.commit()
            messagebox.showinfo("Success", f"Package {package_name} installed successfully!")
    except KeyError:
        messagebox.showerror("Error", f"Package {package_name} not found.")

def remove_package(package_name):
    try:
        pkg = cache[package_name]
        if pkg.is_installed:
            pkg.mark_delete()
            cache.commit()
            messagebox.showinfo("Success", f"Package {package_name} removed successfully!")
        else:
            messagebox.showinfo("Info", f"{package_name} is not installed.")
    except KeyError:
        messagebox.showerror("Error", f"Package {package_name} not found.")

def search_package():
    search_term = search_entry.get().lower()
    results = [pkg.name for pkg in cache if search_term in pkg.name.lower()]
    display_search_results(results)

def display_search_results(results):
    search_results_listbox.delete(0, tk.END)
    if not results:
        search_results_listbox.insert(tk.END, "No results found.")
    else:
        for result in results:
            search_results_listbox.insert(tk.END, result)

# Set up the GUI
root = tk.Tk()
root.title("APT Package Manager")

# Search Section
search_label = tk.Label(root, text="Search for Package:")
search_label.grid(row=0, column=0, padx=10, pady=10)

search_entry = tk.Entry(root)
search_entry.grid(row=0, column=1, padx=10, pady=10)

search_button = tk.Button(root, text="Search", command=search_package)
search_button.grid(row=0, column=2, padx=10, pady=10)

# Search Results Listbox
search_results_listbox = tk.Listbox(root, width=50, height=10)
search_results_listbox.grid(row=1, column=0, columnspan=3, padx=10, pady=10)

# Install/Remove Package Section
action_label = tk.Label(root, text="Install or Remove Package:")
action_label.grid(row=2, column=0, padx=10, pady=10)

action_entry = tk.Entry(root)
action_entry.grid(row=2, column=1, padx=10, pady=10)

install_button = tk.Button(root, text="Install", command=lambda: install_package(action_entry.get()))
install_button.grid(row=2, column=2, padx=10, pady=10)

remove_button = tk.Button(root, text="Remove", command=lambda: remove_package(action_entry.get()))
remove_button.grid(row=3, column=2, padx=10, pady=10)

root.mainloop()
