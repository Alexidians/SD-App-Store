from PyQt5.QtCore import QUrl, QDir
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings
from PyQt5.QtWidgets import QApplication, QMainWindow

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Youtube")
        
        # Set up custom directory for persistent storage
        storage_dir = "data"
        if not QDir(storage_dir).exists():
            QDir().mkdir(storage_dir)  # Create the "data" directory if it doesn't exist

        # Create a WebEngineView
        self.browser = QWebEngineView(self)
        
        # Set the custom storage path for the browser's cache
        self.browser.page().profile().setCachePath(storage_dir + "/cache")
        self.browser.page().profile().setPersistentStoragePath(storage_dir + "/persistent")
        profile = self.browser.page().profile()
        profile.settings().setAttribute(QWebEngineSettings.PluginsEnabled, True)
        profile.settings().setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        profile.settings().setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
        profile.settings().setAttribute(QWebEngineSettings.AllowRunningInsecureContent, True)
        profile.settings().setAttribute(QWebEngineSettings.AutoLoadImages, True)
        profile.settings().setAttribute(QWebEngineSettings.JavascriptCanOpenWindows, True)
        profile.settings().setAttribute(QWebEngineSettings.JavascriptCanAccessClipboard, True)
        profile.settings().setAttribute(QWebEngineSettings.ScreenCaptureEnabled, True)
        profile.settings().setAttribute(QWebEngineSettings.WebGLEnabled, True)
        profile.settings().setAttribute(QWebEngineSettings.Accelerated2dCanvasEnabled, True)
        profile.settings().setAttribute(QWebEngineSettings.AllowGeolocationOnInsecureOrigins, True)
        profile.settings().setAttribute(QWebEngineSettings.WebRTCPublicInterfacesOnly, False)
        profile.settings().setAttribute(QWebEngineSettings.FullScreenSupportEnabled, True)
        profile.setHttpUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36")
        # Load the webpage
        self.browser.setUrl(QUrl("https://youtube.com"))  # Set your URL here
        self.setCentralWidget(self.browser)

        self.resize(1024, 768)  # Set window size

if __name__ == "__main__":
    app = QApplication([])
    window = Browser()
    window.show()
    app.exec_()
