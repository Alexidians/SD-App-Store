from PyQt5.QtCore import QUrl, QDir
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings
from PyQt5.QtWidgets import QApplication, QMainWindow

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Whatsapp")
        
        # Set up custom directory for persistent storage
        storage_dir = "data"
        if not QDir(storage_dir).exists():
            QDir().mkdir(storage_dir)  # Create the "data" directory if it doesn't exist

        # Create a WebEngineView
        self.browser = QWebEngineView(self)
        
        # Set the custom storage path for the browser's cache
        self.browser.page().profile().setCachePath(storage_dir + "/cache")
        self.browser.page().profile().setPersistentStoragePath(storage_dir + "/persistent")
        self.browser.page().profile().setHttpUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36")
        
        # Load the webpage
        self.browser.setUrl(QUrl("https://web.whatsapp.com"))  # Set your URL here
        self.setCentralWidget(self.browser)

        self.resize(1024, 768)  # Set window size

if __name__ == "__main__":
    app = QApplication([])
    window = Browser()
    window.show()
    app.exec_()
