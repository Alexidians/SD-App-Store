from PyQt5.QtCore import QUrl, QDir
from PyQt5.QtWebEngineCore import QWebEngineProfile
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage
import os

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Whatsapp")
        
        # Set up custom profile for persistent storage in "data/" directory
        storage_dir = "data"
        os.makedirs("data", exist_ok=True)

        # Create and set up the custom profile
        profile = QWebEngineProfile.defaultProfile()
        profile.setCachePath(storage_dir + "/cache")
        profile.setPersistentStoragePath(storage_dir + "/persistent")

        # Set up QWebEngineView to load the webpage with the custom profile
        self.browser = QWebEngineView(self)
        self.browser.setPage(QWebEnginePage(profile, self.browser))
        self.browser.setUrl(QUrl("https://web.whatsapp.org"))  # Set your URL here
        self.setCentralWidget(self.browser)

        self.resize(1024, 768)  # Set window size

if __name__ == "__main__":
    app = QApplication([])
    window = Browser()
    window.show()
    app.exec_()
